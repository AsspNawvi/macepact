package com.custommaces.listeners;

import com.custommaces.CustomMaces;
import com.custommaces.MaceType;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;

import java.util.Random;

public class MaceSmashListener implements Listener {
    private final CustomMaces plugin;
    private final Random random = new Random();

    public MaceSmashListener(CustomMaces plugin) {
        this.plugin = plugin;
    }

    // Called from MaceHitListener on 3rd hit
    public static void triggerSmash(Player player, LivingEntity target, MaceType mace, CustomMaces plugin) {
        MaceSmashListener listener = new MaceSmashListener(plugin);
        switch (mace) {
            case MAGMA -> listener.doMagmaSmash(player, target);
            case ECHO -> listener.doEchoSmash(player, target);
            case SOUL -> listener.doSoulSmash(player, target);
            case ENDER_VOID -> listener.doVoidSmash(player, target);
            case NATURE -> listener.doNatureSmash(player, target);
            case STORM -> listener.doStormSmash(player, target);
            case FROST -> listener.doFrostSmash(player, target);
            case BLOOD -> listener.doBloodSmash(player, target);
            case SPEED -> listener.doSpeedSmash(player, target);
            case GOD -> listener.doGodSmash(player, target);
        }
    }

    private void doMagmaSmash(Player player, LivingEntity target) {
        Vector dir = player.getLocation().getDirection();
        Location eye = player.getEyeLocation();
        for (int i = 0; i < 2; i++) {
            Vector offset = dir.clone().rotateAroundY(i == 0 ? 0.2 : -0.2);
            SmallFireball fireball = player.getWorld().spawn(eye.clone().add(offset), SmallFireball.class);
            fireball.setVelocity(offset.multiply(1.5));
            fireball.setShooter(player);
        }
        player.getWorld().playSound(player.getLocation(), Sound.ENTITY_BLAZE_SHOOT, 1.0f, 1.0f);
    }

    private void doEchoSmash(Player player, LivingEntity target) {
        if (plugin.getMaceManager().isEchoBeamOnCooldown(player)) return;
        plugin.getMaceManager().setEchoBeamCooldown(player);

        Location eye = player.getEyeLocation();
        Vector dir = eye.getDirection();
        LivingEntity hit = null;
        for (double d = 0; d < 20; d += 0.5) {
            Location check = eye.clone().add(dir.clone().multiply(d));
            for (Entity e : player.getWorld().getNearbyEntities(check, 0.5, 0.5, 0.5)) {
                if (e instanceof LivingEntity living && e != player) {
                    hit = living;
                    break;
                }
            }
            if (hit != null) break;
        }

        if (hit != null) {
            hit.damage(8.0, player); // 4 hearts max
            hit.addPotionEffect(new PotionEffect(PotionEffectType.DARKNESS, 60, 0, false, true, true));
            hit.getWorld().spawnParticle(Particle.SONIC_BOOM, hit.getLocation(), 10, 0.5, 0.5, 0.5, 0);
            hit.playSound(hit.getLocation(), Sound.ENTITY_WARDEN_SONIC_BOOM, 1.0f, 1.0f);
        }
    }

    private void doSoulSmash(Player player, LivingEntity target) {
        EntityType[] hostile = {
            EntityType.ZOMBIE, EntityType.SKELETON, EntityType.SPIDER,
            EntityType.CREEPER, EntityType.WITCH, EntityType.ENDERMAN,
            EntityType.HUSK, EntityType.STRAY, EntityType.DROWNED
        };
        EntityType mob = hostile[random.nextInt(hostile.length)];
        Location spawnLoc = target.getLocation().add(random.nextDouble() * 4 - 2, 0, random.nextDouble() * 4 - 2);
        player.getWorld().spawnEntity(spawnLoc, mob);
        player.getWorld().spawnParticle(Particle.SOUL, spawnLoc, 30, 1, 1, 1, 0.05);
        player.getWorld().playSound(spawnLoc, Sound.ENTITY_WITHER_SPAWN, 0.5f, 1.0f);
    }

    private void doVoidSmash(Player player, LivingEntity target) {
        int charges = plugin.getMaceManager().getVoidBreathCharges(player);
        if (charges <= 0) {
            player.sendActionBar(net.kyori.adventure.text.Component.text("No dragon breath charges!", net.kyori.adventure.text.format.TextColor.color(0xFF5555)));
            return;
        }
        plugin.getMaceManager().useVoidBreathCharge(player);

        Location loc = target.getLocation();
        AreaEffectCloud cloud = player.getWorld().spawn(loc, AreaEffectCloud.class);
        cloud.setParticle(Particle.DRAGON_BREATH);
        cloud.setRadius(3.0f);
        cloud.setDuration(100);
        cloud.setCustomName("Dragon Breath");
        cloud.setSource(player);
        player.getWorld().playSound(loc, Sound.ENTITY_ENDER_DRAGON_SHOOT, 1.0f, 1.0f);
    }

    private void doNatureSmash(Player player, LivingEntity target) {
        // Vine grapple - pull target to player or teleport player to block
        Location eye = player.getEyeLocation();
        Vector dir = eye.getDirection();
        Block block = player.getTargetBlockExact(30);
        if (block != null && block.getType().isSolid()) {
            Location dest = block.getLocation().add(0, 1, 0);
            player.teleport(dest);
            player.getWorld().spawnParticle(Particle.BLOCK_CRUMBLE, player.getLocation(), 50, 1, 1, 1, 0.1, Bukkit.createBlockData(Material.OAK_LEAVES));
        } else {
            // Pull target to player
            Vector pull = player.getLocation().toVector().subtract(target.getLocation().toVector()).normalize().multiply(2.0);
            target.setVelocity(pull.add(new Vector(0, 0.5, 0)));
        }
        player.getWorld().playSound(player.getLocation(), Sound.BLOCK_VINE_BREAK, 1.0f, 1.0f);
    }

    private void doStormSmash(Player player, LivingEntity target) {
        player.getWorld().strikeLightning(player.getLocation());
        player.setVelocity(new Vector(0, 2.5, 0));
        player.addPotionEffect(new PotionEffect(PotionEffectType.SLOW_FALLING, 60, 0, false, true, true));
        player.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, player.getLocation(), 50, 1, 1, 1, 0.3);
    }

    private void doFrostSmash(Player player, LivingEntity target) {
        Location eye = player.getEyeLocation();
        Vector dir = eye.getDirection();
        LivingEntity hit = null;
        for (double d = 0; d < 25; d += 0.5) {
            Location check = eye.clone().add(dir.clone().multiply(d));
            player.getWorld().spawnParticle(Particle.SNOWFLAKE, check, 2, 0.1, 0.1, 0.1, 0.01);
            for (Entity e : player.getWorld().getNearbyEntities(check, 0.5, 0.5, 0.5)) {
                if (e instanceof LivingEntity living && e != player) {
                    hit = living;
                    break;
                }
            }
            if (hit != null) break;
        }
        if (hit != null) {
            hit.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 60, 9, false, true, true)); // Full freeze
            hit.addPotionEffect(new PotionEffect(PotionEffectType.JUMP_BOOST, 60, 128, false, true, true));
            hit.getWorld().spawnParticle(Particle.SNOWFLAKE, hit.getLocation(), 50, 0.5, 1, 0.5, 0.01);
            hit.playSound(hit.getLocation(), Sound.BLOCK_GLASS_BREAK, 1.0f, 1.5f);
        }
    }

    private void doBloodSmash(Player player, LivingEntity target) {
        int streak = plugin.getMaceManager().getKillStreak(player);
        double bonus = streak * 2.0; // +2 hearts per kill streak level
        if (bonus > 0) {
            target.damage(bonus, player);
            player.getWorld().spawnParticle(Particle.DAMAGE_INDICATOR, target.getLocation(), 20, 0.5, 0.5, 0.5, 0.2);
        }
    }

    private void doSpeedSmash(Player player, LivingEntity target) {
        plugin.getMaceManager().setDashCharges(player, 3);
        player.getWorld().spawnParticle(Particle.CLOUD, player.getLocation(), 30, 0.5, 0.5, 0.5, 0.2);
        player.playSound(player.getLocation(), Sound.ENTITY_PHANTOM_FLAP, 1.0f, 1.5f);
    }

    private void doGodSmash(Player player, LivingEntity target) {
        MaceType selected = plugin.getMaceManager().getGodMaceSelection(player);
        triggerSmash(player, target, selected, plugin);
    }

    // God Mace shift+right click to cycle abilities
    @EventHandler
    public void onPlayerInteract(PlayerInteractEvent event) {
        if (event.getAction() != Action.RIGHT_CLICK_AIR && event.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        Player player = event.getPlayer();
        if (!player.isSneaking()) return;

        ItemStack item = player.getInventory().getItemInMainHand();
        MaceType mace = MaceType.fromItemStack(item, plugin);
        if (mace != MaceType.GOD) return;
        if (plugin.getMaceManager().isHoldingShield(player)) return;

        plugin.getMaceManager().cycleGodMaceSelection(player);
        event.setCancelled(true);
    }
}
